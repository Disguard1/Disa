<body>
<x-header />

<div class="user-info">
    
    <p>Имя: </p>
    <p>Почта: </p>
    <p>Пароль: </p>

</div>
</body>